import type { AudioQuality, IOSOutputFormat } from './RecordingConstants';

/**
 * Represents audio source information returned from native.
 * This is the object returned when reading sources from a queue.
 */
export type AudioSourceInfo = {
  /**
   * A string representing the resource identifier for the audio.
   */
  uri?: string;
  /**
   * An optional display name for the audio source.
   */
  name?: string;
};

// @docsMissing
export type AudioSource =
  | string
  | number
  | null
  | {
      /**
       * A string representing the resource identifier for the audio,
       * which could be an HTTPS address, a local file path, or the name of a static audio file resource.
       */
      uri?: string;
      /**
       * The asset ID of a local audio asset, acquired with the `require` function.
       * This property is exclusive with the `uri` property. When both are present, the `assetId` will be ignored.
       */
      assetId?: number;
      /**
       * An object representing the HTTP headers to send along with the request for a remote audio source.
       * On web requires the `Access-Control-Allow-Origin` header returned by the server to include the current domain.
       */
      headers?: Record<string, string>;
      /**
       * An optional display name for the audio source.
       * Useful for showing track names in a queue or playlist UI.
       */
      name?: string;
    };

/**
 * Options for configuring audio player behavior.
 */
export type AudioPlayerOptions = {
  /**
   * How often (in milliseconds) to emit playback status updates. Defaults to 500ms.
   *
   * @example
   * ```tsx
   * import { useAudioPlayer } from 'expo-audio';
   *
   * export default function App() {
   *   const player = useAudioPlayer(source);
   *
   *   // High-frequency updates for smooth progress bars
   *   const player = useAudioPlayer(source, { updateInterval: 100 });
   *
   *   // Standard updates (default behavior)
   *   const player = useAudioPlayer(source, { updateInterval: 500 });
   *
   *   // Low-frequency updates for better performance
   *   const player = useAudioPlayer(source, { updateInterval: 1000 });
   * }
   * ```
   *
   * @default 500ms
   *
   * @platform ios
   * @platform android
   * @platform web
   */
  updateInterval?: number;
  /**
   * If set to `true`, the system will attempt to download the resource to the device before loading.
   * This value defaults to `false`.
   *
   * Works with:
   * - Local assets from `require('path/to/file')`
   * - Remote HTTP/HTTPS URLs
   * - Asset objects
   *
   * When enabled, this ensures the audio file is fully downloaded before playback begins.
   * This can improve playback performance and reduce buffering, especially for users
   * managing multiple audio players simultaneously.
   *
   * On Android and iOS, this will download the audio file to the device's tmp directory before playback begins.
   * The system will purge the file at its discretion.
   *
   * On web, this will download the audio file to the user's device memory and make it available for the user to play.
   * The system will usually purge the file from memory after a reload or on memory pressure.
   * On web, CORS restrictions apply to the blob url, so you need to make sure the server returns the `Access-Control-Allow-Origin` header.
   *
   * @platform ios
   * @platform web
   * @platform android
   */
  downloadFirst?: boolean;
  /**
   * Determines the [cross origin policy](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Attributes/crossorigin) used by the underlying native view on web.
   * If `undefined` (default), does not use CORS at all. If set to `'anonymous'`, the audio will be loaded with CORS enabled.
   * Note that some audio may not play if CORS is enabled, depending on the CDN settings.
   * If you encounter issues, consider adjusting the `crossOrigin` property.
   *
   *
   * @platform web
   * @default undefined
   */
  crossOrigin?: 'anonymous' | 'use-credentials';
  /**
   * If set to `true`, the audio session will not be deactivated when this player pauses or finishes playback.
   * This prevents interrupting other audio sources (like videos) when the audio ends.
   *
   * Useful for sound effects that should not interfere with ongoing video playback or other audio.
   * The audio session for this player will not be deactivated automatically when the player finishes playback.
   *
   * > **Note:** If needed, you can manually deactivate the audio session using `setIsAudioActiveAsync(false)`.
   *
   * @platform ios
   * @default false
   */
  keepAudioSessionActive?: boolean;
  /**
   * The duration in seconds the player should buffer ahead of the current playback position.
   * A higher value improves playback stability at the cost of more memory/network usage.
   *
   * - **iOS**: Maps to `AVPlayerItem.preferredForwardBufferDuration`. A value of `0` lets the system decide.
   * - **Android**: Configures ExoPlayer's `DefaultLoadControl` max buffer duration.
   * - **Web**: Not applicable (browser manages buffering).
   *
   * @default 0 (system default)
   *
   * @platform ios
   * @platform android
   */
  preferredForwardBufferDuration?: number;
};

/**
 * Options for configuring audio preloading behavior.
 */
export type PreloadOptions = {
  /**
   * The duration in seconds the player should buffer ahead of the current playback position.
   * A higher value improves playback stability at the cost of more memory/network usage.
   *
   * - **iOS**: Maps to `AVPlayerItem.preferredForwardBufferDuration`. A value of `0` lets the system decide.
   * - **Android**: Configures ExoPlayer's buffer duration.
   * - **Web**: Not applicable (browser manages buffering).
   *
   * @default 10
   *
   * @platform ios
   * @platform android
   */
  preferredForwardBufferDuration?: number;
};

/**
 * @deprecated Use `AudioPlayerOptions` instead.
 * Options for audio loading behavior.
 */
export type AudioLoadOptions = AudioPlayerOptions;

/**
 * Represents an available audio input device for recording.
 *
 * This type describes audio input sources like built-in microphones, external microphones,
 * or other audio input devices that can be used for recording. Each input has an identifying
 * information that can be used to select the preferred recording source.
 */
export type RecordingInput = {
  /** Human-readable name of the audio input device. */
  name: string;
  /** Type or category of the input device (for example, 'Built-in Microphone', 'External Microphone'). */
  type: string;
  /** Unique identifier for the input device, used to select the input ('Built-in Microphone', 'External Microphone') for recording. */
  uid: string;
};

/**
 * Pitch correction quality settings for audio playback rate changes.
 *
 * When changing playback rate, pitch correction can be applied to maintain the original pitch.
 * Different quality levels offer trade-offs between processing power and audio quality.
 *
 * @platform ios
 */
export type PitchCorrectionQuality = 'low' | 'medium' | 'high';

/**
 * Comprehensive status information for an `AudioPlayer`.
 *
 * This object contains all the current state information about audio playback,
 * including playback position, duration, loading state, and playback settings.
 * Used by `useAudioPlayerStatus()` to provide real-time status updates.
 */
export type AudioStatus = {
  /** Unique identifier for the player instance. */
  id: string;
  /** Current playback position in seconds. */
  currentTime: number;
  /** String representation of the player's internal playback state. */
  playbackState: string;
  /** String representation of the player's time control status (playing/paused/waiting). */
  timeControlStatus: string;
  /** Reason why the player is waiting to play (if applicable). */
  reasonForWaitingToPlay: string;
  /** Whether the player is currently muted. */
  mute: boolean;
  /** Total duration of the audio in seconds, or 0 if not yet determined. */
  duration: number;
  /** Whether the audio is currently playing. */
  playing: boolean;
  /** Whether the audio is set to loop when it reaches the end. */
  loop: boolean;
  /** Whether the audio just finished playing. */
  didJustFinish: boolean;
  /** Whether the player is currently buffering data. */
  isBuffering: boolean;
  /** Whether the audio has finished loading and is ready to play. */
  isLoaded: boolean;
  /** Current playback rate (1.0 = normal speed). */
  playbackRate: number;
  /**
   * Whether pitch correction is enabled for rate changes.
   * @default true
   */
  shouldCorrectPitch: boolean;
  /**
   * Whether the media services were reset by the system.
   * When `true`, the player was interrupted because the system's media daemon crashed.
   * The player will automatically attempt to recover by reloading the source and resuming playback.
   * @platform ios
   */
  mediaServicesDidReset?: boolean;
  /**
   * Whether the current audio source is a live stream with indefinite duration.
   */
  isLive: boolean;
  /**
   * Seconds behind the live edge, or `null` if not a live stream
   * or if the offset cannot be determined.
   * @platform ios
   * @platform android
   */
  currentOffsetFromLive: number | null;
  /**
   * Playback error message, or `null` if no error.
   * Cleared when a new source is loaded or playback resumes successfully.
   */
  error: string | null;
};

/**
 * Status information for recording operations from the event system.
 *
 * This type represents the status data emitted by `recordingStatusUpdate` events.
 * It contains high-level information about the recording session and any errors.
 * Used internally by the event system. Most users should use `useAudioRecorderState()` instead.
 */
export type RecordingStatus = {
  /** Unique identifier for the recording session. */
  id: string;
  /** Whether the recording has finished (stopped). */
  isFinished: boolean;
  /** Whether an error occurred during recording. */
  hasError: boolean;
  /** Error message if an error occurred, `null` otherwise. */
  error: string | null;
  /** File URL of the completed recording, if available. */
  url: string | null;
  /**
   * Whether the media services were reset by the system.
   * When `true`, the recording was interrupted because the system's media daemon crashed.
   * The recorder is now invalid and must be re-prepared by calling `prepareToRecordAsync()`.
   * @platform ios
   */
  mediaServicesDidReset?: boolean;
};

/**
 * Current state information for an `AudioRecorder`.
 *
 * This object contains detailed information about the recorder's current state,
 * including recording status, duration, and technical details. This is what you get
 * when calling `recorder.getStatus()` or using `useAudioRecorderState()`.
 */
export type RecorderState = {
  /** Whether the recorder is ready and able to record. */
  canRecord: boolean;
  /** Whether recording is currently in progress. */
  isRecording: boolean;
  /** Duration of the current recording in milliseconds. */
  durationMillis: number;
  /** Whether the media services have been reset (typically indicates a system interruption). */
  mediaServicesDidReset: boolean;
  /** Current audio level/volume being recorded (if metering is enabled). */
  metering?: number;
  /** File URL where the recording will be saved, if available. */
  url: string | null;
};

/**
 * Audio output format options for Android recording.
 *
 * Specifies the container format for recorded audio files on Android.
 * Different formats have different compatibility and compression characteristics.
 *
 * @platform android
 */
export type AndroidOutputFormat =
  | 'default'
  | '3gp'
  | 'mpeg4'
  | 'amrnb'
  | 'amrwb'
  | 'aac_adts'
  | 'mpeg2ts'
  | 'webm';

/**
 * Audio encoder options for Android recording.
 *
 * Specifies the audio codec used to encode recorded audio on Android.
 * Different encoders offer different quality, compression, and compatibility trade-offs.
 *
 * @platform android
 */
export type AndroidAudioEncoder = 'default' | 'amr_nb' | 'amr_wb' | 'aac' | 'he_aac' | 'aac_eld';

/**
 * Bit rate strategies for audio encoding.
 *
 * Determines how the encoder manages bit rate during recording, affecting
 * file size consistency and quality characteristics.
 */
export type BitRateStrategy = 'constant' | 'longTermAverage' | 'variableConstrained' | 'variable';

/**
 * Options for controlling how audio recording is started.
 */
export type RecordingStartOptions = {
  /**
   * The duration in seconds after which recording should automatically stop.
   * If not provided, recording continues until manually stopped.
   *
   * @platform ios
   * @platform android
   * @platform web
   */
  forDuration?: number;
  /**
   * The time in seconds to wait before starting the recording.
   * If not provided, recording starts immediately.
   *
   * **Platform behavior:**
   * - Android: Ignored, recording starts immediately
   * - iOS: Uses native AVAudioRecorder.record(atTime:) for precise timing.
   * - Web: Ignored, recording starts immediately
   *
   * > **warning** On iOS, the recording process starts immediately (you'll see status updates),
   * but actual audio capture begins after the specified delay. This is not a countdown, since
   * the recorder is active but silent during the delay period.
   *
   * @platform ios
   */
  atTime?: number;
};

/**
 * Directory where the recording file is stored.
 *
 * - `cache`: Stores recordings in the app cache directory, a place to store files that can be deleted by the system when the device runs low on storage.
 * - `document`: Stores recordings in the app document directory, a place to store files that are safe from being deleted by the system.
 *
 * @platform android
 * @platform ios
 */
export type RecordingDirectory = 'cache' | 'document';

export type RecordingOptions = {
  /**
   * The directory where the recording file should be stored.
   *
   * @default 'cache'
   * @platform android
   * @platform ios
   */
  directory?: RecordingDirectory;
  /**
   * A boolean that determines whether audio level information will be part of the status object under the "metering" key.
   */
  isMeteringEnabled?: boolean;
  /**
   * The desired file extension.
   *
   * @example .caf
   */
  extension: string;
  /**
   * The desired sample rate.
   *
   * @example 44100
   */
  sampleRate: number;
  /**
   * The desired number of channels.
   *
   * @example 2
   */
  numberOfChannels: number;
  /**
   * The desired bit rate.
   *
   * @example 128000
   */
  bitRate: number;
  /**
   * Recording options for the Android platform.
   * @platform android
   */
  android: RecordingOptionsAndroid;
  /**
   * Recording options for the iOS platform.
   * @platform ios
   */
  ios: RecordingOptionsIos;
  /**
   * Recording options for the Web platform.
   * @platform web
   */
  web: RecordingOptionsWeb;
};

/**
 * Recording options for the web.
 *
 * Web recording uses the `MediaRecorder` API, which has different capabilities
 * compared to native platforms. These options map directly to `MediaRecorder` settings.
 *
 * @platform web
 */
export type RecordingOptionsWeb = {
  /** MIME type for the recording (for example, 'audio/webm', 'audio/mp4'). */
  mimeType?: string;
  /** Target bits per second for the recording. */
  bitsPerSecond?: number;
};

/**
 * Recording configuration options specific to iOS.
 *
 * iOS recording uses `AVAudioRecorder` with extensive format and quality options.
 * These settings provide fine-grained control over the recording characteristics.
 *
 * @platform ios
 */
export type RecordingOptionsIos = {
  /**
   * The desired file extension.
   *
   * @example .caf
   */
  extension?: string;
  /**
   * The desired sample rate.
   *
   * @example 44100
   */
  sampleRate?: number;
  /**
   * The desired file format. See the [`IOSOutputFormat`](#iosoutputformat) enum for all valid values.
   */
  outputFormat?: string | IOSOutputFormat | number;
  /**
   * The desired audio quality. See the [`AudioQuality`](#audioquality) enum for all valid values.
   */
  audioQuality: AudioQuality | number;
  /**
   * The desired bit rate strategy. See the next section for an enumeration of all valid values of `bitRateStrategy`.
   */
  bitRateStrategy?: number;
  /**
   * The desired bit depth hint.
   *
   * @example 16
   */
  bitDepthHint?: number;
  /**
   * The desired PCM bit depth.
   *
   * @example 16
   */
  linearPCMBitDepth?: number;
  /**
   * A boolean describing if the PCM data should be formatted in big endian.
   */
  linearPCMIsBigEndian?: boolean;
  /**
   * A boolean describing if the PCM data should be encoded in floating point or integral values.
   */
  linearPCMIsFloat?: boolean;
};

/**
 * Recording configuration options specific to Android.
 *
 * Android recording uses `MediaRecorder` with options for format, encoder, and file constraints.
 * These settings control the output format and quality characteristics.
 *
 * @platform android
 */
export type RecordingOptionsAndroid = {
  /**
   * The desired file extension.
   *
   * @example .caf
   */
  extension?: string;
  /**
   * The desired sample rate.
   *
   * @example 44100
   */
  sampleRate?: number;
  /**
   * The desired file format. See the [`AndroidOutputFormat`](#androidoutputformat) type for all valid values.
   */
  outputFormat: AndroidOutputFormat;
  /**
   * The desired audio encoder. See the [`AndroidAudioEncoder`](#androidaudioencoder) type for all valid values.
   */
  audioEncoder: AndroidAudioEncoder;
  /**
   * The desired maximum file size in bytes, after which the recording will stop (but `stopAndUnloadAsync()` must still
   * be called after this point).
   *
   * @example
   * `65536`
   */
  maxFileSize?: number;
  /**
   * The desired audio Source. See the [`RecordingSource`](#recordingsource) type for all valid values.
   */
  audioSource?: RecordingSource;
};

export type AudioMode = {
  /**
   * Determines if audio playback is allowed when the device is in silent mode.
   * On Android, when `false`, playback is suppressed when the ringer mode is silent or vibrate.
   *
   * @default true
   */
  playsInSilentMode: boolean;
  /**
   * Determines how the audio session interacts with other audio sessions.
   *
   * - `'doNotMix'`: Requests exclusive audio focus. Other apps will pause their audio.
   * - `'duckOthers'`: Requests audio focus with ducking. Other apps lower their volume but continue playing.
   * - `'mixWithOthers'`: Audio plays alongside other apps without interrupting them.
   *   On Android, this means no audio focus is requested. Best suited for sound effects,
   *   UI feedback, or short audio clips.
   *
   * @default 'mixWithOthers'
   */
  interruptionMode: InterruptionMode;
  /**
   * Determines how the audio session interacts with other sessions on Android.
   *
   * @platform android
   * @deprecated Use `interruptionMode` instead, which now works on both platforms.
   */
  interruptionModeAndroid?: InterruptionModeAndroid;
  /**
   * Whether the audio session allows recording.
   *
   * @default false
   * @platform ios
   */
  allowsRecording: boolean;
  /**
   * Whether the audio session stays active when the app moves to the background.
   *
   * > **Note**: On Android, you have to enable the lockscreen controls with [`setActiveForLockScreen`](#setactiveforlockscreenactive-metadata-options) for sustained background playback. Otherwise, the audio will stop after approximately 3 minutes of background playback (OS limitation). Make sure to also appropriately [configure the config-plugin](#configuration-in-app-config).
   * @default false
   */
  shouldPlayInBackground: boolean;
  /**
   * Whether the audio should route through the earpiece.
   * On iOS, this only has an effect when `allowsRecording` is `true` (i.e., the audio session
   * category is `.playAndRecord`). When `false` (the default), audio is routed through the speaker.
   * @default false
   */
  shouldRouteThroughEarpiece: boolean;
  /**
   * Whether audio recording should continue when the app moves to the background.
   *
   * @default false
   * @platform ios
   * @platform android
   */
  allowsBackgroundRecording?: boolean;
};

/**
 * Audio interruption behavior modes.
 *
 * Controls how your app's audio interacts with other apps' audio.
 *
 * - `'doNotMix'`: Requests exclusive audio focus. Other apps will pause their audio.
 * - `'duckOthers'`: Requests audio focus with ducking. Other apps lower their volume but continue playing.
 * - `'mixWithOthers'`: Audio plays alongside other apps without interrupting them.
 *
 *   On Android, this means no audio focus is requested. Best suited for sound effects,
 *   UI feedback, or short audio clips. Note that on Android your app won't receive
 *   audio focus loss callbacks (for example, during phone calls) when using this mode.
 *
 *  > **Note:** When using `setActiveForLockScreen`, this must be set to `doNotMix`.
 *
 * @default 'mixWithOthers'
 */
export type InterruptionMode = 'mixWithOthers' | 'doNotMix' | 'duckOthers';

/**
 * @deprecated Use `InterruptionMode` instead, which now works on both platforms.
 */
export type InterruptionModeAndroid = InterruptionMode;

/**
 * Recording source for android.
 *
 * An audio source defines both a default physical source of audio signal, and a recording configuration.
 *
 * - `camcorder`: Microphone audio source tuned for video recording, with the same orientation as the camera if available.
 * - `default`: The default audio source.
 * - `mic`: Microphone audio source.
 * - `unprocessed`: Microphone audio source tuned for unprocessed (raw) sound if available, behaves like `default` otherwise.
 * - `voice_communication`: Microphone audio source tuned for voice communications such as VoIP. It will for instance take advantage of echo cancellation or automatic gain control if available.
 * - `voice_performance`: Source for capturing audio meant to be processed in real time and played back for live performance (e.g karaoke). The capture path will minimize latency and coupling with playback path.
 * - `voice_recognition`: Microphone audio source tuned for voice recognition.
 *
 * @see https://developer.android.com/reference/android/media/MediaRecorder.AudioSource
 * @platform android
 */
export type RecordingSource =
  | 'camcorder'
  | 'default'
  | 'mic'
  | 'remote_submix'
  | 'unprocessed'
  | 'voice_communication'
  | 'voice_performance'
  | 'voice_recognition';

// @docsMissing
export type AudioMetadata = {
  title?: string;
  artist?: string;
  albumTitle?: string;
  artworkUrl?: string;
};

/**
 * Loop mode for audio playlist playback.
 *
 * - `'none'`: No looping. Playback stops after the last track.
 * - `'single'`: Loops the current track indefinitely.
 * - `'all'`: Loops the entire playlist, returning to the first track after the last.
 */
export type AudioPlaylistLoopMode = 'none' | 'single' | 'all';

/**
 * Options for configuring an audio playlist.
 */
export type AudioPlaylistOptions = {
  /**
   * Initial sources to add to the playlist. Each source can be a local asset, remote URL, or null.
   * @default []
   */
  sources?: AudioSource[];

  /**
   * How often (in milliseconds) to emit playback status updates. Defaults to 500ms.
   * @default 500
   */
  updateInterval?: number;

  /**
   * Loop mode for the playlist.
   * - `'none'`: No looping (default)
   * - `'single'`: Loop the current track
   * - `'all'`: Loop the entire playlist
   * @default 'none'
   */
  loop?: AudioPlaylistLoopMode;

  /**
   * Sets the `crossOrigin` attribute on the `<audio>` elements used for playback.
   * Required for CORS-enabled audio files when you need to access audio data.
   * @platform web
   * @default undefined
   */
  crossOrigin?: 'anonymous' | 'use-credentials';
};

/**
 * Status information for an audio playlist.
 */
export type AudioPlaylistStatus = {
  /** Unique identifier for the playlist instance. */
  id: string;
  /** Index of the currently playing track in the playlist. */
  currentIndex: number;
  /** Total number of tracks in the playlist. */
  trackCount: number;
  /** Current playback position in seconds. */
  currentTime: number;
  /** Total duration of the current track in seconds. */
  duration: number;
  /** Whether the player is currently playing. */
  playing: boolean;
  /** Whether the player is buffering. */
  isBuffering: boolean;
  /** Whether the current track has finished loading. */
  isLoaded: boolean;
  /** Current playback rate (1.0 = normal speed). */
  playbackRate: number;
  /** Whether the player is muted. */
  muted: boolean;
  /** Current volume level (0.0 to 1.0). */
  volume: number;
  /** Current loop mode. */
  loop: AudioPlaylistLoopMode;
  /** Whether the current track just finished playing. */
  didJustFinish: boolean;
};
